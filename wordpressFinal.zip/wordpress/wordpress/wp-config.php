<?php
/** 
 * Configuración básica de WordPress.
 *
 * Este archivo contiene las siguientes configuraciones: ajustes de MySQL, prefijo de tablas,
 * claves secretas, idioma de WordPress y ABSPATH. Para obtener más información,
 * visita la página del Codex{@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} . Los ajustes de MySQL te los proporcionará tu proveedor de alojamiento web.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

//Ampliacion de memoria
define ('WP_MEMORY_LIMIT', '64M');

// ** Ajustes de MySQL. Solicita estos datos a tu proveedor de alojamiento web. ** //
/** El nombre de tu base de datos de WordPress */
define('DB_NAME', 'tienda');

/** Tu nombre de usuario de MySQL */
define('DB_USER', 'root');

/** Tu contraseña de MySQL */
define('DB_PASSWORD', '');

/** Host de MySQL (es muy probable que no necesites cambiarlo) */
define('DB_HOST', 'localhost');

/** Codificación de caracteres para la base de datos. */
define('DB_CHARSET', 'utf8');

/** Cotejamiento de la base de datos. No lo modifiques si tienes dudas. */
define('DB_COLLATE', '');

/**#@+
 * Claves únicas de autentificación.
 *
 * Define cada clave secreta con una frase aleatoria distinta.
 * Puedes generarlas usando el {@link https://api.wordpress.org/secret-key/1.1/salt/ servicio de claves secretas de WordPress}
 * Puedes cambiar las claves en cualquier momento para invalidar todas las cookies existentes. Esto forzará a todos los usuarios a volver a hacer login.
 *
 * @since 2.6.0
 */
define('AUTH_KEY', '4i(gOhH# fbWLbTpS9SiPjLB-$jC;aC?&Kn|H/6j8vip]3x5X&(FXOWpvKbq<$E`');
define('SECURE_AUTH_KEY', 'Z|tguER5@d2-g7)SVEu:dV`@XI{7#^Q,p:_^JN+E(7-7Mg2$q|-d3Q)fB*kS0L9=');
define('LOGGED_IN_KEY', 'j1$N2xOl&+6]#=F|.< rANFHwO:[.?G wx7sk-y1#HTC|]g($4wv~;he<|o>hhPz');
define('NONCE_KEY', 'Wj}35[r=.ao=e|[Y:z|6M4Vekg*kfj%2a}c{N|_rXB},$3 q@b7T;w)VqW6fttU-');
define('AUTH_SALT', '[pIs8p>X3 &* >+f%|P{:o`h|F_@/[:CciqMy+b.4N)H2nlCsiTL-OijYPvqCHI<');
define('SECURE_AUTH_SALT', 'F-fEkGTyQD<YDc+d+y`yk^J,U&|z[j4(0a9b]:z{PO/a0w3)y?r;([ZzFTO&>$6J');
define('LOGGED_IN_SALT', ']ulZB-^4<2N_9fh,H<Uw~nr8Uf<((loo>B+DV 6Fb-r[9|B82C;Ky&CYI0naYw^E');
define('NONCE_SALT', '<~=(k*=L_~ ~6vPr@B9Ct1rE;{^NYO2AA}-ky1h2#h5Pt,l(|]_Z71m-uzgO0!#]');

/**#@-*/

/**
 * Prefijo de la base de datos de WordPress.
 *
 * Cambia el prefijo si deseas instalar multiples blogs en una sola base de datos.
 * Emplea solo números, letras y guión bajo.
 */
$table_prefix  = 'wp_';


/**
 * Para desarrolladores: modo debug de WordPress.
 *
 * Cambia esto a true para activar la muestra de avisos durante el desarrollo.
 * Se recomienda encarecidamente a los desarrolladores de temas y plugins que usen WP_DEBUG
 * en sus entornos de desarrollo.
 */
define('WP_DEBUG', false);

/* ¡Eso es todo, deja de editar! Feliz blogging */

/** WordPress absolute path to the Wordpress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');

